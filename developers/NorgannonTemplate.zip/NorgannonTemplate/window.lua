-- The window: a UI.Window with a search box and a UI.List of the suite's add-ons.

local Core = NorgannonCore
local A = NorgannonTemplate
if not A or A.disabled then return end
local UI = Core.UI
local C = UI.C

local Window = {}
A.Window = Window

local W, H, ROW = 420, 360, 34
local win, list, search

local STATE_TEXT = { loaded = "running", off = "turned off", installed = "installed, not running", missing = "not installed" }
local STATE_COLOR = { loaded = C.text, off = C.bad, installed = C.muted, missing = C.faint }

local function createRow(row, content)
  row.mark = UI.Mark(content, "norgannondb", 22)
  row.mark:SetPoint("LEFT", 8, 0)
  row.name = UI.Text(content, "bold", 13)
  row.name:SetPoint("TOPLEFT", row.mark, "TOPRIGHT", 8, 2)
  row.state = UI.Text(content, "body", 12, C.muted)
  row.state:SetPoint("TOPLEFT", row.name, "BOTTOMLEFT", 0, -1)
end

local function updateRow(row, item)
  row.mark:SetTexture(UI.MarkPath(item.key))
  local accent = UI.Accent(item.key)
  row.name:SetText(item.name)
  row.name:SetTextColor(accent[1], accent[2], accent[3])
  local color = STATE_COLOR[item.state]
  row.state:SetText(item.role .. "  ·  " .. STATE_TEXT[item.state])
  row.state:SetTextColor(color[1], color[2], color[3])
end

local function items()
  local query = search and string.lower(search:GetText() or "") or ""
  local out = {}
  for _, info in ipairs(Core.SUITE) do
    local state = Core:AddonState(info.key)
    local matches = query == "" or string.find(string.lower(info.name), query, 1, true)
    if matches and (A.db.showMissing or state ~= "missing") then
      out[#out + 1] = { key = info.key, name = info.name, role = info.role, state = state }
    end
  end
  return out
end

---How many of the suite's add-ons are installed (for the minimap status line).
function Window:InstalledCount()
  local n = 0
  for _, info in ipairs(Core.SUITE) do
    if Core:AddonState(info.key) ~= "missing" then n = n + 1 end
  end
  return n
end

local function build()
  win = UI.Window({ name = "NorgannonTemplateWindow", addon = A.key, title = A.name, sub = "The suite", width = W, height = H,
    footer = true })
  win:Hide()
  search = UI.Search(win.body, "Search add-ons…", function() Window:Refresh() end, nil, "/tpl")
  search:SetPoint("TOPLEFT", 14, -10)
  search:SetPoint("TOPRIGHT", -14, -10)
  local pane = UI.Pane(win.body)
  pane:SetPoint("TOPLEFT", search, "BOTTOMLEFT", 0, -10)
  pane:SetPoint("BOTTOMRIGHT", -14, 12)
  list = UI.List(pane, { rowHeight = ROW, createRow = createRow, updateRow = updateRow })
  list:SetAllPoints()
  win.footerText:SetText("Settings: right-click the minimap row, or /tpl settings")
end

function Window:IsShown() return win ~= nil and win:IsShown() end

function Window:Refresh()
  if win and win:IsShown() then list:SetData(items(), true) end
end

function Window:Toggle()
  if not win then build() end
  if win:IsShown() then
    win:Hide()
  else
    win:SetScale(A.db.scale)
    win:Show()
    A.char.opened = A.char.opened + 1
    self:Refresh()
  end
end

function Window:ResetPosition()
  if not win then build() end
  win:ClearAllPoints()
  win:SetPoint("CENTER")
end

-- Another add-on starting changes the list
Core:Listen("NORGANNON_ADDON_REGISTERED", "template.window", function() Window:Refresh() end)
