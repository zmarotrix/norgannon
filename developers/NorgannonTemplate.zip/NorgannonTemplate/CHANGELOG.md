# Changelog

## 0.1.0, 2026-11-07

- First version: the suite's add-ons in a window with a search box, a settings page, and /template.
