-- Norgannon Template: the smallest complete add-on on NorgannonDB Core. It shows the suite's add-ons and whether each
-- is installed, in a suite window with a search box. Read docs/dev/getting-started.md alongside it.
--
-- Two rules every add-on keeps (docs/dev/forever-rules.md):
--   1. A value that may be secret is never compared, added or turned into text: read the client with Core.Plain.
--   2. Protected frames are only touched out of combat: use Core:AfterCombat.

local ADDON = ...
local Core = NorgannonCore

-- An older Core has no NewAddon: say so once and stop. This is the only hand-written version check.
if not (Core and Core.NewAddon) then
  print("Norgannon Template needs NorgannonDB Core 1.19 or newer; it is turned off.")
  return
end

-- An add-on outside the suite's registry passes its own name, accent and role (and a mark texture if it has one).
-- A suite add-on (a key in Core.SUITE) passes only its key and folder: the rest comes from the registry.
local A = Core:NewAddon("template", {
  folder = ADDON,
  global = "NorgannonTemplate",
  name = "Norgannon Template", accent = "7fb7a6", role = "An example add-on",
  api = { 1, 19 },          -- the Core API this was written for; a newer 1.x Core keeps serving it
  -- data = { 1, 4 },       -- uncomment if you read NorgannonDB, and add NorgannonDB to the TOC's Dependencies

  db = "NorgannonTemplateDB",
  version = 2,
  defaults = {
    showMissing = true,     -- list suite add-ons that aren't installed
    scale = 1,
  },
  migrate = {
    -- version 2 renamed "hideMissing" to "showMissing": a migration runs once, and the old key is gone for good
    [2] = function(db)
      if db.hideMissing ~= nil then db.showMissing = not db.hideMissing end
      db.hideMissing = nil
    end,
  },
  char = "NorgannonTemplateCharDB",
  charDefaults = { opened = 0 },

  slash = { "/template", "/tpl" },
  commands = {
    reset = { function() NorgannonTemplate.Window:ResetPosition() end, "put the window back in the middle" },
  },
  minimap = {
    -- a live line for the tooltip and the flyout's status
    status = function()
      local n = NorgannonTemplate.Window and NorgannonTemplate.Window:InstalledCount()
      return n and (n .. " suite add-ons installed") or nil
    end,
  },
})
if A.disabled then return end

---The main action: left-click on the minimap row or in the add-on menu, and /template on its own.
function A:Toggle()
  self.Window:Toggle()
end
