# Norgannon Template

A small, complete add-on on NorgannonDB Core, kept as a test fixture: `tools/harness/platform_test.py` drives
`Core:NewAddon` through it on every deploy. It also reads as a worked example next to `docs/dev/getting-started.md`.

| File | What it shows |
|---|---|
| `core.lua` | `Core:NewAddon`: the version check, saved variables with defaults and a migration, the slash command, the minimap row |
| `window.lua` | `UI.Window`, `UI.Search`, `UI.Pane`, `UI.List`, the registry, a Core message |
| `settings.lua` | `UI.SettingsList` and `A:AddSettingsPage` |

It isn't shipped or deployed.
