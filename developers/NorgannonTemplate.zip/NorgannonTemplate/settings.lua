-- The settings page, under NorgannonDB in the game's Settings window. There's no minimap setting here: NorgannonDB's
-- Minimap page pins any add-on, so add-ons don't repeat it.

local Core = NorgannonCore
local A = NorgannonTemplate
if not A or A.disabled then return end
local UI = Core.UI

A:OnReady(function()
  local page = CreateFrame("Frame")
  page:Hide()
  local list = UI.SettingsList(page)

  list:Header("Window")
  list:Toggle("Show add-ons that aren't installed", "They're listed in grey, so you can see what the suite offers.",
    function() return A.db.showMissing end, function(on) A.db.showMissing = on A.Window:Refresh() end)
  list:Slider("Size", "The window's scale.", .7, 1.4, .05, function() return A.db.scale end,
    function(v) A.db.scale = v end, "%.0f%%", 100)
  list:Buttons("Position", "Puts the window back in the middle of the screen.",
    { { "Reset", function() A.Window:ResetPosition() end } })

  page:SetScript("OnShow", function() list:Refresh() end)
  A.settingsList = list
  A:AddSettingsPage(page)
end)
